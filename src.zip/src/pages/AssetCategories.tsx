import { PageHeader } from "@/components/common/PageHeader";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Tags } from "lucide-react";
import { toast } from "sonner";
import { useData } from "@/contexts/data";
import { uniqueValues } from "@/lib/live-data";
import { useEffect, useState } from "react";
import { fetchTicketCategories, fetchTicketsByCategory } from "@/services/tickets";

function CategoryGrid({ items, count }: { items: string[]; count: (c: string) => number }) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
      {items.map(c => (
        <Card key={c} className="p-4 hover:shadow-md transition-shadow">
          <div className="flex items-start justify-between">
            <div className="h-9 w-9 rounded-md bg-info/10 text-info grid place-items-center"><Tags className="h-4 w-4" /></div>
            <span className="text-xs font-medium text-muted-foreground">{count(c)}</span>
          </div>
          <div className="mt-3 font-medium text-sm">{c}</div>
          <div className="text-xs text-muted-foreground">Category</div>
        </Card>
      ))}
    </div>
  );
}

export default function AssetCategoriesPage() {
  const { assets } = useData();
  const categories = uniqueValues(assets.map((asset) => asset.category));
  return (
    <>
      <PageHeader title="Asset Categories" description="Classification schema for the asset catalog."
        actions={<Button onClick={() => toast.success("Category added")}><Plus className="h-4 w-4 mr-1" />Add Category</Button>} />
      {categories.length === 0 ? (
        <Card className="p-8 text-center text-sm text-muted-foreground">No asset categories found.</Card>
      ) : (
        <CategoryGrid items={categories} count={(c) => assets.filter(a => a.category === c).length} />
      )}
    </>
  );
}

export function TicketCategoriesInner() {
  const [categories, setCategories] = useState<any[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<any>(null);
  const [tickets, setTickets] = useState<any[]>([]);

  useEffect(() => {
    loadCategories();
  }, []);

  async function loadCategories() {
    try {
      const res = await fetchTicketCategories();
      setCategories(res.categories || []);
    } catch (err) {
      console.error(err);
      toast.error("Failed to load ticket categories");
    }
  }
  async function openCategory(categoryName: string) {
    try {
      const res = await fetchTicketsByCategory(categoryName);

      setSelectedCategory(categoryName);
      setTickets(res.tickets || []);
    } catch (err) {
      console.error(err);
      toast.error("Failed to load tickets");
    }
  }

  return (
    <>
      <PageHeader
        title="Ticket Categories"
        description="Group and route tickets to the right team."
        actions={
          <Button>
            <Plus className="h-4 w-4 mr-1" />
            Add Category
          </Button>
        }
      />

      {categories.length === 0 ? (
        <Card className="p-8 text-center text-sm text-muted-foreground">
          No ticket categories found.
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Side */}
          <div className="lg:col-span-4">
            <div className="grid gap-3">
              {categories.map((category) => (
                <Card
                  key={category.name}
                  className="p-4 hover:shadow-md transition-shadow cursor-pointer"
                  onClick={() => openCategory(category.name)}
                >
                  <div className="flex items-start justify-between">
                    <div className="h-9 w-9 rounded-md bg-info/10 text-info grid place-items-center">
                      <Tags className="h-4 w-4" />
                    </div>
                    <span className="text-xs font-medium text-muted-foreground">
                      {category.ticketCount}
                    </span>
                  </div>
                  <div className="mt-3 font-medium text-sm">
                    {category.name}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Category
                  </div>
                </Card>
              ))}
            </div>
          </div>
          {/* Right Side */}
          <div className="lg:col-span-8">
            <Card className="h-full min-h-[500px] flex items-center justify-center">
              <div className="text-center">
                <Tags className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <h2 className="text-lg font-semibold">
                  Select a Category
                </h2>
                <p className="text-muted-foreground mt-2">
                  Click any ticket category to view the raised tickets.
                </p>
              </div>
            </Card>
          </div>
        </div>
      )}
    </>
  );
}
